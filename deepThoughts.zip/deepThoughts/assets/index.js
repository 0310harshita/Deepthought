var array = [{
    text: "Threadbuild",
    Description: "Story of Alignment Scope of Agility Specific Accontable Staggering Approach",
    loading: true,
    image: "https://www.youtube.com/embed/s7DbVTkaXn0",
    section: []
},
{
    text: "Threadbuild",

    section: [{
        name: "Section 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    },
    {
        name: "Section 2",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    },
    ]
},
{
    text: "Threadbuild",
    Description: "Story of Alignment Scope of Agility Specific Accontable Staggering Approach",

    section: [{
        name: "Section 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    },
    {
        name: "Section 3",

        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    }]
}, {
    text: "shiva",
    Description: "Story of Alignment Scope of Agility Specific Accontable Staggering Approach",

    section: [{
        name: "Section 1",
        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    },
    {
        name: "Section 3",

        description: "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."
    }]
}]

var index = -1;
const myClick = (e) => {
    document.querySelectorAll('.panel p')[e].classList.toggle("hide")
}



function handleChild(data) {
    var v = ""
    data.forEach(item => {
        index++;
        v += `<div class="panel"><button class="accordion" onclick="myClick(${index})">${item.name}</button>
        <p>${item.description}</p>
        </div>
        `
    })
    return v
}

function generateThreadbuild() {
    var thread = ""

    array.forEach(data => {
        thread += `<div class="first-card">
    <div class="headline">
        ${data.text}
    </div>
    ${data.Description ? ` <p style=""><strong>Description:</strong> ${data.Description}Approach</p>` : ''
            }
            ${data.image ? `<div class="iframe-content">
          
            <iframe width="100%" height="100%" src=${data.image}
                title="Animals of Amazon 4K - Animals That Call The Jungle Home | Amazon Rainforest |Scenic Relaxation Film"
                frameborder="0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowfullscreen></iframe>
        </div>`: ""}
       `+ handleChild(data.section, index) + `
</div>`

    })

    document.getElementById("thread").innerHTML = thread;
}